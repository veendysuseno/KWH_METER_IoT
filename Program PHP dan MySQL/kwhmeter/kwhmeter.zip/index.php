<?php include('layout/header.php') ?>
<?php include('layout/navbar.php') ?>

<div class="container">

    <h1>Dashboard</h1>

    <div class="row row-cols-1 row-cols-md-3 g-4">

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Voltage</p>
                    <h1 class="card-text" id='voltage'>219.2 V</h1>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Current</p>
                    <h1 class="card-text" id='current'>0.1 A</h1>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Power</p>
                    <h1 class="card-text" id='power'>10 W</h1>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Energy</p>
                    <h1 class="card-text" id='energy'>20 KWH</h1>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Freq</p>
                    <h1 class="card-text" id='freq'>50 Hz</h1>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Pf</p>
                    <h1 class="card-text" id='pf'>1</h1>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Estimasi Harga</p>
                    <h1 class="card-text" id='harga'>3500 Rupiah</h1>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Estimasi Harga WBP</p>
                    <h1 class="card-text" id='harga_wbp'>5500 Rupiah</h1>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <p class="card-title">Estimasi Harga LWBP</p>
                    <h1 class="card-text" id='harga_lwbp'>6500 Rupiah</h1>
                </div>
            </div>
        </div>

    </div>

    <p class="mt-5">Terakhir Update: <strong id='waktu'>2021-07-01 00:00:00</strong></p>

</div>

<script>
    if (typeof(EventSource) !== "undefined") {
        var source = new EventSource("sse_data.php");
        source.addEventListener('data', function(e) {
            var data = JSON.parse(e.data);

            var tanggal = data.tanggal;
            var waktu = data.waktu;
            var voltage = data.voltage;
            var current = data.current;
            var power = data.power;
            var energy = data.energy;
            var freq = data.freq;
            var pf = data.pf;

            var harga = energy * 1650;
            var harga_wbp = energy * 2500;
            var harga_lwbp = energy * 7500;

            document.getElementById("voltage").innerText = voltage + " V";
            document.getElementById("current").innerText = current + " A";
            document.getElementById("power").innerText = power + " W";
            document.getElementById("energy").innerText = energy + " KWH";
            document.getElementById("freq").innerText = freq + " Hz";
            document.getElementById("pf").innerText = pf;
            document.getElementById("waktu").innerText = tanggal + " " + waktu;
            document.getElementById("harga").innerText = harga + " Rupiah";
            document.getElementById("harga_wbp").innerText = harga_wbp + " Rupiah";
            document.getElementById("harga_lwbp").innerText = harga_lwbp + " Rupiah";

        }, false);
    } else {
        document.getElementById("result").innerHTML = "Not Support";
    }
</script>


<?php include('layout/footer.php') ?>